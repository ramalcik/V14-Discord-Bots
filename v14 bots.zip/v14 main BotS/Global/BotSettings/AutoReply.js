const { ramal_Yes, red } = require("../../ramalcim-Bots/ramalcim-Main/src/configs/emojis.json")

module.exports = {
    
"YetersizYetki": `${red} \`Yetersiz Yetki\` Bu komutu kullanmak için yeterli yetkiye sahip değilsin.`,
"KendiniKayit": `${red} \`Hatalı İşlem\` Kendini Kayıt Edemezsin!`,
"AyniKullanici": `${red} \`Hatalı İşlem\` Kendini Ve Seninle Aynı Rolü Taşıyanı Kayıtsıza Atamazsın!`,

    
}