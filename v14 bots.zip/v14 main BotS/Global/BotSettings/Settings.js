module.exports = {
 
    GuildID: "",
    GuildName: "",
    owners: [""],
    BotDurum: [""], 
    BotSesKanal: "",
    AltBaşlık: "",
    
DatabaseURL: "",
    
        Welcome: {
            Active: true,
            Tokens: [
               "MTE2NjUzNzA4MDE1MTc1Njg2MQ.GW8Ita.MxlstXsTiTYxSHx8Byik",
               "MTE2NjUzNzM0MjE0MDU0NzA3Mg.GISg53nxhWoX07F2xWeQ"
    
            ],
            Channels: [
                "1162577440539951142",
                "1162577440539951143"
            ]
        },
    
    
       
    Main: {
        ModerationToken: "MTE3MTA4MzYxMjU5OTM1Mz0",
        RegisterToken: "MTE3MTA4NDQwNTQxOTI3ODQzNg",
        StatsToken: "MTE3MTA4NTky",

        prefix: [
            ".",
            "!"
        ],

        BotClientID: "1171083612599353425",
    
            dmMessages: true,
            LevelSystem: true,
    
            messageDolar: 1,
            voiceDolar: 1,
          
            messageCount: 1,
            messageCoin: 2,
            voiceCount: 1,
            voiceCoin: 4,
            publicCoin: 4,
            inviteCount: 1,
            inviteCoin: 15,
            taggedCoin: 25,
            toplamsCoin: 5.5,
            yetkiCoin: 30,
          
            banlimit: 3,
            jaillimit: 3,
            warnlimit: 3,
            chatmutelimit: 3,
            voicemutelimit: 3,
        
        },
    
        Guard: {
            Token: {
                Guard_I: "MTE3MTA4NTkyNTIyOTUzNTMxMg.GkxoZBskQ0PBh3D5BKU",
                Guard_II: "MTE3MTA4NTkyNTIyOTUzNTMxMg.G4WmpM.CMMm9BskQ0PBh3D5BKU",
                Guard_III: "MTE3MTA4NTkyNTIyOTUzNTMxMg.G4WmpM.CMMm9pVrPBh3D5BKU",
    
                TaçHesapToken: "", 
                UrlGuardToken: "",
    
                Dağıtıcı: [
                   ""
                ]
            },
    
            Limit: {
                Ban: 1,
                Kick: 1,
                RoleCreate: 1,
                ChannelCreate: 2,
    
                Reklam: 5,
                Etiket: 5,
                Satır: 5,
                Ekler: 5
            },
    
            Guard: {
                TaskDelay: 250,
                GiveRoleDelay: 500
            },
    
            kufurEngel: true,
            spamEngel: true,
            capsEngel: true,
            reklamEngel: true
    
        }
    }



