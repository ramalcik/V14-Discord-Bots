module.exports = {

CommandChannel: ["bot-commands","bot-command","bot-komut"],


}